package com.example.krpizzaPrj.mappers;

import com.example.krpizzaPrj.dto.ItemDto;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface AdminMapper {

    @Insert("INSERT INTO items VALUES(null, #{itemName}, #{itemIntro}, #{itemPrice}, #{itemSize}, #{itemImage}, null)")
    void setAddItem(ItemDto itemDto);
}
