package com.example.krpizzaPrj.controller;


import com.example.krpizzaPrj.dto.ItemDto;
import com.example.krpizzaPrj.dto.UsersDto;
import com.example.krpizzaPrj.mappers.CommonMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class CommonController {

        @Autowired
        CommonMapper commonMapper;

        //--------------------회원가입 페이지--------------------
        @GetMapping("/common/register")
        public String getRegister() {

            return "common/register";
        }

        @PostMapping("/common/register")
        @ResponseBody
        public Map<String, Object> setRegister(@ModelAttribute UsersDto usersDto) {
            System.out.println(usersDto);
            Map<String, Object> map = new HashMap<>();
            if( usersDto != null ) {
                commonMapper.setRegister(usersDto);
                map.put("msg", "회원가입이 완료되었습니다.");
            }
            return map;
        }


    //--------------------회원정보(로그인, 아이디, 비밀번호) 찾기 페이지--------------------
        @GetMapping("/common/checkUserId")
        @ResponseBody
        public Map<String, Object> getCheckUserId(@RequestParam String userId) {
            int CheckUserId = commonMapper.getCheckUserId(userId);

            return Map.of("checkUserId", CheckUserId);
        }

        @GetMapping("/common/checkUserEmail")
        @ResponseBody
        public Map<String, Object> getCheckUserEmail(@RequestParam String userEmail) {
            int CheckUserEmail = commonMapper.getCheckUserEmail(userEmail);

            return Map.of("CheckUserEmail", CheckUserEmail);
        }

        @GetMapping("/common/findID")
        public String getFindID() {

            return "common/findID";
        }
        @GetMapping("/common/findPw")
        public String getFindPw() {

            return "common/findPw";
        }

        @GetMapping("/common/login")
        public String getLogin() {

            return "common/login";
        }

        @PostMapping("/common/checkLogin")
        @ResponseBody
        public Map<String, Object> checkLogin(@RequestParam String userId, @RequestParam String userPasswd ) {
            Map<String, Object> map = new HashMap<>();


            return Map.of("checkLogin", commonMapper.checkLogin(userId,userPasswd ));
        }

        @PostMapping("/common/checkFindID")
        @ResponseBody
        public Map<String, Object> checkFindID(@RequestParam String userName, @RequestParam String userEmail ) {
            Map<String, Object> map = new HashMap<>();


            return Map.of("FindID", commonMapper.checkFindID(userName, userEmail));
        }

    //--------------------메인 페이지--------------------
        @GetMapping("/common/mainPage")
        public String getMainPage() {

            return "common/mainPage";
        }
        @GetMapping("/user/afterLogin")
        public String getAfterLogin() {

            return "user/afterLogin";
        }

    //--------------------매장 페이지--------------------
        @GetMapping("/common/map")
        public String getMap() {

            return "common/map";
        }

    //--------------------이벤트 페이지--------------------
        @GetMapping("/common/eventPage")
        public String getEventPage() {
            return "common/eventPage";
        }
        @GetMapping("/common/endEventPage")
        public String getEndEventPage() {
            return "common/endEventPage";
        }

    //--------------------메뉴 페이지--------------------

    @GetMapping("/common/premium")
    public String getPremium(Model model) {
        Map<String, Object> map = new HashMap<>();

        System.out.println(commonMapper.getPremium());
        model.addAttribute("premium", commonMapper.getPremium());

        return "common/premium";
    }
    @GetMapping("/common/original")
    public String getOriginal(Model model) {
        Map<String, Object> map = new HashMap<>();

        System.out.println(commonMapper.getOriginal());
        model.addAttribute("original", commonMapper.getOriginal());

        return "common/original";
    }

}