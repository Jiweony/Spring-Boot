package com.example.krpizzaPrj.controller;

import com.example.krpizzaPrj.dto.ItemDto;
import com.example.krpizzaPrj.mappers.AdminMapper;
import com.example.krpizzaPrj.mappers.CommonMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.UUID;

@Controller
public class AdminController {
    @Value("${fileDir}")
    String fileDir;

    @Autowired
    AdminMapper adminMapper;

    //메뉴 리스트 보기
    @GetMapping("/admin/itemList")
    public String getItemList(){
        return "admin/itemList";
    }


    //메뉴 추가하기
    @GetMapping("/admin/addItem")
    public String getAddItem(){
        return "admin/addItem";
    }

    @PostMapping("/admin/addItem")
    public String setAddItem(Model model, @RequestParam("file") MultipartFile file, @ModelAttribute ItemDto itemDto) throws IOException {

        //파일 저장
        String folderName = new SimpleDateFormat("yyyyMMdd").format(System.currentTimeMillis());
        File makeFolder = new File(fileDir + folderName);

        if(!makeFolder.exists()) {
            makeFolder.mkdir();
        }

        String oriName = file.getOriginalFilename();
        String uuid = UUID.randomUUID().toString();
        String ext = oriName.substring(oriName.lastIndexOf("."));

        String savedFileName = uuid + ext; //이미지 표시할 때
        String savedPathFileName = fileDir + folderName + "/" + savedFileName; //다운로드

        //파일쓰기
        file.transferTo(new File(savedPathFileName));

        //html파일로 이미지 보기
        model.addAttribute("savedFileName", savedFileName);
        model.addAttribute("folderName", folderName);
        model.addAttribute("savedPathFileName", savedPathFileName);

        itemDto.setItemImage(savedFileName);

        //메뉴정보 저장
        adminMapper.setAddItem(itemDto);
        System.out.println(itemDto);
        return "/admin/addItem";
    }


}
